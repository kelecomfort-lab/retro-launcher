package com.alt.retrolauncher

import android.content.Context
import android.content.Intent
import android.graphics.Color as AColor
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

// ---------- Colours (taken from the screenshot) ----------
val Cream = Color(0xFFF0E8DC)
val Paper = Color(0xFFF8F4EA)
val Ink = Color(0xFF1A1410)
val Red = Color(0xFFD81F2A)
val Muted = Color(0xFF6B5E55)
val GridLine = Color(0x14000000)

// ---------- Fonts ----------
// Built-in condensed bold font. To get the exact poster look, add Anton.ttf
// to res/font and swap this for FontFamily(Font(R.font.anton)).
val Heading = FontFamily(Typeface.create("sans-serif-condensed", Typeface.BOLD))
val Body = FontFamily(Typeface.create("sans-serif-medium", Typeface.NORMAL))

class MainActivity : ComponentActivity() {
    private val refresh = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bars = SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT)
        enableEdgeToEdge(statusBarStyle = bars, navigationBarStyle = bars)
        setContent { LauncherApp(refresh.intValue) }
    }

    // Re-scan the app list whenever we come back to the home screen
    override fun onResume() {
        super.onResume()
        refresh.intValue++
    }
}

// ---------- Data ----------
data class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)

fun loadApps(context: Context): List<AppItem> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != context.packageName }
        .map {
            AppItem(
                label = it.loadLabel(pm).toString(),
                pkg = it.activityInfo.packageName,
                // Tiny 32px icon, scaled up later with no smoothing = pixel look
                icon = it.loadIcon(pm).toBitmap(32, 32).asImageBitmap()
            )
        }
        .sortedBy { it.label.lowercase() }
}

fun launch(context: Context, pkg: String) {
    context.packageManager.getLaunchIntentForPackage(pkg)?.let { context.startActivity(it) }
}

fun openAppInfo(context: Context, pkg: String) {
    context.startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

enum class Tab { HOME, APPS }

// ---------- Main screen ----------
@Composable
fun LauncherApp(refreshKey: Int) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("launcher", Context.MODE_PRIVATE) }

    val apps by produceState(emptyList<AppItem>(), refreshKey) {
        value = withContext(Dispatchers.Default) { loadApps(context) }
    }

    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())!!.toSet()) }
    fun toggleFav(pkg: String) {
        favs = if (pkg in favs) favs - pkg else favs + pkg
        prefs.edit().putStringSet("favs", favs).apply()
    }

    var tab by remember { mutableStateOf(Tab.HOME) }
    BackHandler(enabled = tab != Tab.HOME) { tab = Tab.HOME }

    Column(
        Modifier
            .fillMaxSize()
            .background(Cream)
            .drawBehind {
                // grid-paper background
                val step = 36.dp.toPx()
                var x = 0f
                while (x < size.width) {
                    drawLine(GridLine, Offset(x, 0f), Offset(x, size.height), 1f); x += step
                }
                var y = 0f
                while (y < size.height) {
                    drawLine(GridLine, Offset(0f, y), Offset(size.width, y), 1f); y += step
                }
            }
            .statusBarsPadding()
    ) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                Tab.HOME -> HomeTab(apps, favs)
                Tab.APPS -> AppsTab(apps, favs, ::toggleFav)
            }
        }
        BottomBar(tab) { tab = it }
    }
}

// ---------- HOME tab ----------
@Composable
fun HomeTab(apps: List<AppItem>, favs: Set<String>) {
    val context = LocalContext.current
    val now by produceState(LocalTime.now()) {
        while (true) { value = LocalTime.now(); delay(10_000) }
    }
    val date = LocalDate.now()
        .format(DateTimeFormatter.ofPattern("EEEE, d MMM", Locale.getDefault()))
        .uppercase()
    val favApps = apps.filter { it.pkg in favs }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Title("HOME") }
        item {
            BrutalBox(Modifier.fillMaxWidth(), shadow = 8.dp) {
                Column(
                    Modifier.padding(24.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        now.format(DateTimeFormatter.ofPattern("HH:mm")),
                        style = TextStyle(fontFamily = Heading, fontSize = 84.sp, color = Ink)
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        date,
                        style = TextStyle(fontFamily = Body, fontSize = 15.sp, color = Muted, letterSpacing = 1.sp)
                    )
                    Spacer(Modifier.height(18.dp))
                    BrutalBox(
                        Modifier.fillMaxWidth(), fill = Red, shadow = 5.dp,
                        onClick = { /* swap this for any action you like */ }
                    ) {
                        Text(
                            "${apps.size} APPS INSTALLED",
                            Modifier.padding(vertical = 14.dp).fillMaxWidth(),
                            textAlign = TextAlign.Center,
                            style = TextStyle(fontFamily = Body, fontWeight = FontWeight.Bold,
                                fontSize = 18.sp, color = Color.White, letterSpacing = 2.sp)
                        )
                    }
                }
            }
        }
        item { Spacer(Modifier.height(4.dp)); Title("FAVOURITES") }
        if (favApps.isEmpty()) {
            item {
                BrutalBox(Modifier.fillMaxWidth(), shadow = 5.dp) {
                    Text(
                        "Nothing pinned yet. Long-press any app in the APPS tab to pin it here.",
                        Modifier.padding(18.dp),
                        style = TextStyle(fontFamily = Body, fontSize = 16.sp, color = Muted)
                    )
                }
            }
        } else {
            items(favApps, key = { it.pkg }) { app ->
                BrutalBox(Modifier.fillMaxWidth(), shadow = 5.dp, onClick = { launch(context, app.pkg) }) {
                    Row(Modifier.padding(14.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(52.dp).border(3.dp, Ink).background(Cream),
                            contentAlignment = Alignment.Center
                        ) { PixelIcon(app.icon, 36.dp) }
                        Spacer(Modifier.width(16.dp))
                        Text(
                            app.label, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = TextStyle(fontFamily = Body, fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Ink)
                        )
                        Text(">", style = TextStyle(fontFamily = Heading, fontSize = 26.sp, color = Ink))
                    }
                }
            }
        }
    }
}

// ---------- APPS tab ----------
@Composable
fun AppsTab(apps: List<AppItem>, favs: Set<String>, onToggleFav: (String) -> Unit) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    val shown = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query, ignoreCase = true) }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Box(Modifier.padding(horizontal = 6.dp, vertical = 16.dp)) { Title("APPS") }

        BrutalBox(Modifier.fillMaxWidth().padding(horizontal = 6.dp), shadow = 5.dp) {
            Box(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                if (query.isEmpty()) {
                    Text("SEARCH APPS", style = TextStyle(fontFamily = Body, fontWeight = FontWeight.Bold,
                        fontSize = 16.sp, color = Muted, letterSpacing = 1.sp))
                }
                BasicTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    cursorBrush = SolidColor(Red),
                    textStyle = TextStyle(fontFamily = Body, fontSize = 16.sp, color = Ink),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Spacer(Modifier.height(14.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 12.dp)
        ) {
            gridItems(shown, key = { it.pkg }) { app ->
                Box(Modifier.padding(5.dp)) {
                    BrutalBox(
                        Modifier.fillMaxWidth(), shadow = 4.dp,
                        onClick = { launch(context, app.pkg) },
                        onLongClick = { onToggleFav(app.pkg) }
                    ) {
                        Column(
                            Modifier.padding(vertical = 10.dp, horizontal = 4.dp).fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box {
                                PixelIcon(app.icon, 40.dp)
                                if (app.pkg in favs) {
                                    Box(Modifier.align(Alignment.TopEnd).size(12.dp).border(2.dp, Ink).background(Red))
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                app.label.uppercase(), maxLines = 1, overflow = TextOverflow.Ellipsis,
                                style = TextStyle(fontFamily = Heading, fontSize = 11.sp, color = Ink, letterSpacing = 0.5.sp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------- Bottom bar (like the screenshot) ----------
@Composable
fun BottomBar(current: Tab, onSelect: (Tab) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Paper)
            .drawBehind { drawLine(Ink, Offset(0f, 0f), Offset(size.width, 0f), 6f) }
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Tab.values().forEach { t ->
            val active = t == current
            BrutalBox(
                Modifier.weight(1f), fill = if (active) Red else Paper, shadow = 4.dp,
                onClick = { onSelect(t) }
            ) {
                Text(
                    t.name, Modifier.padding(vertical = 12.dp).fillMaxWidth(), textAlign = TextAlign.Center,
                    style = TextStyle(fontFamily = Body, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                        color = if (active) Color.White else Ink, letterSpacing = 2.sp)
                )
            }
        }
    }
}

// ---------- Reusable pieces ----------
@Composable
fun Title(text: String) {
    Text(text, style = TextStyle(fontFamily = Heading, fontSize = 48.sp, color = Ink))
}

@Composable
fun PixelIcon(bitmap: ImageBitmap, size: Dp) {
    Image(
        bitmap = bitmap, contentDescription = null, modifier = Modifier.size(size),
        filterQuality = FilterQuality.None // no smoothing = chunky pixels
    )
}

/** A box with a thick black outline and a hard offset shadow. Sinks in when pressed. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BrutalBox(
    modifier: Modifier = Modifier,
    fill: Color = Paper,
    shadow: Dp = 6.dp,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val shift = if (pressed) shadow else 0.dp

    Box(modifier.padding(end = shadow, bottom = shadow)) {
        Box(Modifier.matchParentSize().offset(shadow, shadow).background(Ink)) // the shadow
        Box(
            Modifier
                .offset(shift, shift)
                .fillMaxWidth()
                .background(fill)
                .border(3.dp, Ink)
                .then(
                    if (onClick != null)
                        Modifier.combinedClickable(
                            interactionSource = source, indication = null,
                            onClick = onClick, onLongClick = onLongClick
                        )
                    else Modifier
                ),
            content = content
        )
    }
}
